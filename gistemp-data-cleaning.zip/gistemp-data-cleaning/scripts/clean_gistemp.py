"""Clean the NASA GISTEMP v4 global land-ocean temperature anomaly table.

Usage:
    python3 scripts/clean_gistemp.py [raw_csv] [clean_csv] [report_txt]

Defaults:
    raw_csv    data/raw/GLB.Ts+dSST.csv
    clean_csv  data/clean/gistemp_global_clean.csv
    report_txt data/clean/cleaning_report.txt

Source of the raw file:
    https://data.giss.nasa.gov/gistemp/tabledata_v4/GLB.Ts+dSST.csv
Values are temperature anomalies in degrees Celsius relative to 1951-1980.
"""
import sys
from io import StringIO

import pandas as pd

RAW = sys.argv[1] if len(sys.argv) > 1 else "data/raw/GLB.Ts+dSST.csv"
CLEAN = sys.argv[2] if len(sys.argv) > 2 else "data/clean/gistemp_global_clean.csv"
REPORT = sys.argv[3] if len(sys.argv) > 3 else "data/clean/cleaning_report.txt"

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
RENAME = {
    "Year": "year",
    **{m: m.lower() for m in MONTHS},
    "J-D": "annual_jan_dec",
    "D-N": "annual_dec_nov",
    "DJF": "winter_djf",
    "MAM": "spring_mam",
    "JJA": "summer_jja",
    "SON": "autumn_son",
}

log = StringIO()


def say(msg=""):
    print(msg)
    log.write(msg + "\n")


# ---------------------------------------------------------------- 1. LOAD RAW
with open(RAW, encoding="utf-8") as f:
    lines = f.read().splitlines()

say("=== BEFORE CLEANING ===")
say(f"Total physical lines in file : {len(lines)}")
say(f"Line 1 (not data)            : {lines[0]!r}")
say(f"Line 2 (real header)         : {lines[1][:60]}...")

# Read everything as text first so nothing is silently coerced.
raw = pd.read_csv(RAW, skiprows=1, dtype=str, keep_default_na=False)
raw.columns = [c.strip() for c in raw.columns]

# Any extra header rows / footer text repeated inside the body?
repeated_hdr = (raw["Year"] == "Year").sum()
non_numeric_year = (~raw["Year"].str.fullmatch(r"\d{4}")).sum()
say(f"Data rows                    : {len(raw)}")
say(f"Repeated header rows         : {repeated_hdr}")
say(f"Rows with non-year 'Year'    : {non_numeric_year}")

value_cols = [c for c in raw.columns if c != "Year"]
stars = (raw[value_cols] == "***").sum()
say(f"Missing-value placeholders ('***') : {int(stars.sum())} cells in "
    f"{int((stars > 0).sum())} columns")
for col, n in stars[stars > 0].items():
    yrs = raw.loc[raw[col] == "***", "Year"].tolist()
    say(f"    {col:>4}: {n} cell(s) -> years {yrs}")

say("Data types as loaded by pandas default (type inference):")
inferred = pd.read_csv(RAW, skiprows=1)
text_cols = [c for c in inferred.columns
             if not pd.api.types.is_numeric_dtype(inferred[c])]
say(f"    columns stored as text because of '***': {text_cols}")

fmt_issue = raw[value_cols].apply(lambda s: s.str.match(r"^-?\.\d")).sum().sum()
say(f"Values written without leading zero (e.g. '.16', '-.19'): {int(fmt_issue)}")

say(f"Fully duplicated rows        : {int(raw.duplicated().sum())}")
say(f"Duplicated Year values       : {int(raw['Year'].duplicated().sum())}")

# ---------------------------------------------------------------- 2. CLEAN
df = raw.copy()
df = df[df["Year"] != "Year"]                       # drop stray header rows (none expected)
df = df.replace({"***": pd.NA, "": pd.NA})          # real missing values
df[value_cols] = df[value_cols].apply(pd.to_numeric, errors="raise")
df["Year"] = pd.to_numeric(df["Year"], errors="raise").astype("int64")
df = df.drop_duplicates()                            # exact duplicates
df = df.drop_duplicates(subset="Year", keep="last")  # one row per year
df = df.rename(columns=RENAME).sort_values("year").reset_index(drop=True)

months_lc = [m.lower() for m in MONTHS]
df["months_present"] = df[months_lc].notna().sum(axis=1).astype("int64")
df["is_complete_year"] = df["months_present"].eq(12)

# ----------------------------------------------------------- 3. VALIDATION
say()
say("=== VALIDATION OF CLEANED DATA ===")
yrs = df["year"]
full_range = set(range(yrs.min(), yrs.max() + 1))
say(f"Year range                   : {yrs.min()} - {yrs.max()} "
    f"({len(df)} rows, gaps: {sorted(full_range - set(yrs)) or 'none'})")

num_cols = months_lc + ["annual_jan_dec", "annual_dec_nov",
                        "winter_djf", "spring_mam", "summer_jja", "autumn_son"]
lo, hi = df[num_cols].min().min(), df[num_cols].max().max()
say(f"Anomaly range                : {lo:.2f} to {hi:.2f} degC (plausible)")

# Cross-check: annual J-D should equal the mean of the 12 monthly values.
# Both are rounded to 0.01, so allow 0.01 tolerance.
comp = df[df["is_complete_year"] & df["annual_jan_dec"].notna()].copy()
comp["calc"] = comp[months_lc].mean(axis=1)
comp["diff"] = (comp["calc"] - comp["annual_jan_dec"]).abs()
bad = comp[comp["diff"] > 0.01]
say(f"J-D vs mean of 12 months     : {len(comp)} complete years checked, "
    f"{len(bad)} differ by more than 0.01")
if len(bad):
    say(bad[["year", "annual_jan_dec", "calc", "diff"]]
        .round(3).to_string(index=False))

# Cross-check: seasonal means vs monthly values.
seasons = {
    "spring_mam": ["mar", "apr", "may"],
    "summer_jja": ["jun", "jul", "aug"],
    "autumn_son": ["sep", "oct", "nov"],
}
for col, ms in seasons.items():
    sub = df[df[ms].notna().all(axis=1) & df[col].notna()]
    d = (sub[ms].mean(axis=1) - sub[col]).abs()
    say(f"{col} vs months {ms}: {len(sub)} rows, {int((d > 0.01).sum())} differ by > 0.01")

say()
say("Remaining missing values by column (after cleaning):")
miss = df[num_cols].isna().sum()
for col, n in miss[miss > 0].items():
    yrs_missing = df.loc[df[col].isna(), "year"].tolist()
    say(f"    {col:>15}: {n} -> years {yrs_missing}")

say()
say("Final dtypes:")
say(df.dtypes.astype(str).to_string())
say(f"Final shape: {df.shape[0]} rows x {df.shape[1]} columns")

# ------------------------------------------------------------------ 4. SAVE
df.to_csv(CLEAN, index=False, float_format="%.2f")
with open(REPORT, "w", encoding="utf-8") as f:
    f.write(log.getvalue())
print(f"\nWrote {CLEAN} and {REPORT}")
